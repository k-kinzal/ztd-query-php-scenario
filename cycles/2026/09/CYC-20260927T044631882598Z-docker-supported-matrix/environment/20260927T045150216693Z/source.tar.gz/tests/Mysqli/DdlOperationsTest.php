<?php

declare(strict_types=1);

namespace Tests\Mysqli;

use Tests\Support\AbstractMysqliTestCase;

/** @spec SPEC-5.1, SPEC-5.2 */
class DdlOperationsTest extends AbstractMysqliTestCase
{
    protected function getTableDDL(): string|array
    {
        return [
            'CREATE TABLE ddl_existing (id INT PRIMARY KEY, val VARCHAR(255))',
            'CREATE TABLE ddl_existing (id INT PRIMARY KEY)',
            'CREATE TABLE ddl_new (id INT PRIMARY KEY, name VARCHAR(255))',
        ];
    }

    protected function getTableNames(): array
    {
        return ['ddl_existing', 'ddl_new'];
    }


    public function testCreateTableThrowsWhenTableExistsPhysically(): void
    {
        $this->expectException(ZtdMysqliException::class);
        $this->expectExceptionMessageMatches('/already exists/i');

        $this->mysqli->query('CREATE TABLE ddl_existing (id INT PRIMARY KEY)');
    }

    public function testCreateTableInShadowWhenNotPhysical(): void
    {
        $this->mysqli->query('CREATE TABLE ddl_new (id INT PRIMARY KEY, name VARCHAR(255))');

        $this->mysqli->query("INSERT INTO ddl_new (id, name) VALUES (1, 'shadow')");

        $result = $this->mysqli->query('SELECT * FROM ddl_new WHERE id = 1');
        $row = $result->fetch_assoc();

        $this->assertSame(1, (int) $row['id']);
        $this->assertSame('shadow', $row['name']);
    }

    public function testDropTableClearsShadowData(): void
    {
        $this->mysqli->query("INSERT INTO ddl_existing (id, val) VALUES (1, 'shadow')");

        $result = $this->mysqli->query('SELECT * FROM ddl_existing WHERE id = 1');
        $row = $result->fetch_assoc();
        $this->assertSame('shadow', $row['val']);

        $this->mysqli->query('DROP TABLE ddl_existing');

        // After DROP, shadow data is cleared; query falls through to physical table
        $result = $this->mysqli->query('SELECT * FROM ddl_existing WHERE id = 1');
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->assertCount(0, $rows);
    }

    public function testTruncateClearsShadowedData(): void
    {
        $this->mysqli->query("INSERT INTO ddl_existing (id, val) VALUES (1, 'a')");
        $this->mysqli->query("INSERT INTO ddl_existing (id, val) VALUES (2, 'b')");

        $result = $this->mysqli->query('SELECT * FROM ddl_existing');
        $this->assertSame(2, $result->num_rows);

        $this->mysqli->query('TRUNCATE TABLE ddl_existing');

        $result = $this->mysqli->query('SELECT * FROM ddl_existing');
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->assertCount(0, $rows);
    }

    public function testUpdateOnShadowCreatedTable(): void
    {
        $this->mysqli->query('CREATE TABLE ddl_new (id INT PRIMARY KEY, name VARCHAR(255))');
        $this->mysqli->query("INSERT INTO ddl_new (id, name) VALUES (1, 'original')");
        $this->mysqli->query("UPDATE ddl_new SET name = 'updated' WHERE id = 1");

        $result = $this->mysqli->query('SELECT name FROM ddl_new WHERE id = 1');
        $row = $result->fetch_assoc();
        $this->assertSame('updated', $row['name']);
    }

    public function testDeleteOnShadowCreatedTable(): void
    {
        $this->mysqli->query('CREATE TABLE ddl_new (id INT PRIMARY KEY, name VARCHAR(255))');
        $this->mysqli->query("INSERT INTO ddl_new (id, name) VALUES (1, 'hello')");
        $this->mysqli->query("INSERT INTO ddl_new (id, name) VALUES (2, 'world')");
        $this->mysqli->query('DELETE FROM ddl_new WHERE id = 1');

        $result = $this->mysqli->query('SELECT * FROM ddl_new');
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->assertCount(1, $rows);
        $this->assertSame(2, (int) $rows[0]['id']);
    }
}
